import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user_model.dart';
import '../view_models/user_view_model.dart';

class UserUpdateScreen extends StatelessWidget {
  final UserModel user;

  UserUpdateScreen({required this.user});

  @override
  Widget build(BuildContext context) {
    final userViewModel = Provider.of<UserViewModel>(context);
    final TextEditingController nameController = TextEditingController(text: user.name);
    final TextEditingController emailController = TextEditingController(text: user.email);

    return Scaffold(
      appBar: AppBar(title: Text("Update User")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: "Email"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                // Update user details
                final updatedUser = UserModel(
                  id: user.id,
                  name: nameController.text,
                  email: emailController.text,
                );

                // Call updateUser from the ViewModel
                await userViewModel.updateUser(updatedUser);

                // Navigate back to the user list screen
                Navigator.pop(context);
              },
              child: Text("Update"),
            ),
          ],
        ),
      ),
    );
  }
}
