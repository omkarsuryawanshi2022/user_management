import '../models/user_model.dart';
import '../services/api_service.dart';

class UserRepository {
  final ApiService _apiService = ApiService();

  Future<List<UserModel>> getUsers() => _apiService.fetchUsers();
  Future<UserModel> addUser(UserModel user) => _apiService.createUser(user);
  Future<UserModel> updateUser(UserModel user) => _apiService.updateUser(user);
  Future<void> deleteUser(int id) => _apiService.deleteUser(id);
}
