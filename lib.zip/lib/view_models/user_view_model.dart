import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../repositories/user_repository.dart';

class UserViewModel extends ChangeNotifier {
  final UserRepository _userRepository = UserRepository();
  List<UserModel> _users = [];
  bool isLoading = false;

  List<UserModel> get users => _users;

  Future<void> fetchUsers() async {
    isLoading = true;
    notifyListeners();
    _users = await _userRepository.getUsers();
    isLoading = false;
    notifyListeners();
  }

  Future<void> addUser(UserModel user) async {
    await _userRepository.addUser(user);
    fetchUsers();
  }

  Future<void> updateUser(UserModel user) async {
    await _userRepository.updateUser(user);
    fetchUsers();
  }

  Future<void> deleteUser(int id) async {
    await _userRepository.deleteUser(id);
    fetchUsers();
  }
}
